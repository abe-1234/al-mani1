<!DOCTYPE html>
<html>
<head>
<title>upload</title>
<?php include("head.php");?>
 </head>
 <body>
 <?php include("menu.php"); ?>
 </br></br></br></br>
 </br></br></br></br>
 </br></br></br></br>
 <form action="uploadphp.php" enctype="multipart/form-data" role="form" method="post"> 
 <input type="file" name="file" size="400">
 <button type="submit" name="import" value="import">Upload</button>
 </form>
 </body>
 </html>