<?php 
include "db.php";
if(isset($_POST["import"]))
{
	echo $filename = $_FILES["file"]["tmp_name"];
	if($_FILES["file"]["size"] > 0)
	{
		$file = fopen($filename,"r");
		while(($empData = fgetcsv($file,10000,",")) !== false)
		{
			$sql = "INSERT INTO tblTrial (name,age,addr) VALUES ('$empData[0]','$empData[1]','$empData[2]')";
		    $res = $mysqli->query($sql);
		    if(!$res)
			{
				echo "Please upload only csv File";
			}
			else{
				echo "CSV file has been Uploaded";
			}
		
		}
		fclose($file);
		
    }
	else
	{echo "Invalid File";}
}
?>